# Exercice dirigé: Template module 2

## Consignes
- Construre le template par défaut du module 2
- Modifier la feuille de style commune
